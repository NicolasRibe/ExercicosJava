package ex_17;

public class Calculadora {

	public Calculadora() {
	}
	
	public double Soma(double v1, double v2) {
		return v1 + v2;
	}
	
	public double subtracao(double v1, double v2) {
		return v1 - v2;
	}
	
	public double multiplicacao(double v1, double v2) {
		return v1 * v2;
	}
	
	public double divisao(double v1, double v2) {
		return v1 / v2;
	}
}
