package ex_14;

public interface Veiculo {
	public void mover();
}
