package ex_14;

public class Bicicleta implements Veiculo{
	
	public Bicicleta() {
		
	}
	
	@Override
	public void mover() {
		System.out.println("Pedalando....");
	}
}
