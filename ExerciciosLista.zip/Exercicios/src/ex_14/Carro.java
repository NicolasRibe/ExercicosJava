package ex_14;

public class Carro implements Veiculo{
	
	public Carro() {
	}

	@Override
	public void mover() {
		System.out.println("Dirigindo.......");
	}
}
